from PyQt5.QtWidgets import QAction, QFileDialog, QDialog
from qgis.core import QgsRasterLayer, Qgis
from qgis.PyQt.QtCore import QCoreApplication, Qt
import os
import pandas as pd

from .band_counter_dialog import BandCounterDialog

class BandCounterPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()

    def initGui(self):
        self.action = QAction("Count Bands", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        dialog = BandCounterDialog()
        dialog.buttonBox.accepted.connect(lambda: self.count_bands(dialog))
        result = dialog.exec_()

    def count_bands(self, dialog):
        input_folder_path = dialog.lineEditInputFolderPath.text()
        output_folder_path = dialog.lineEditOutputFolderPath.text()

        if not os.path.isdir(input_folder_path):
            self.iface.messageBar().pushMessage("Error", "Invalid input folder path", level=Qgis.Critical)
            return

        if not os.path.isdir(output_folder_path):
            self.iface.messageBar().pushMessage("Error", "Invalid output folder path", level=Qgis.Critical)
            return

        data = []
        files = [f for f in os.listdir(input_folder_path) if f.lower().endswith(('.tif', '.tiff'))]
        total_files = len(files)

        dialog.progressBar.setValue(0)
        dialog.progressBar.setMaximum(total_files)

        for index, file in enumerate(files):
            file_path = os.path.join(input_folder_path, file)
            layer = QgsRasterLayer(file_path, file)
            if layer.isValid():
                bands = layer.bandCount()
                data.append([file, bands])

            dialog.progressBar.setValue(index + 1)

        df = pd.DataFrame(data, columns=["Filename", "Number of Bands"])
        output_file = os.path.join(output_folder_path, "band_counts.xlsx")
        df.to_excel(output_file, index=False)

        self.iface.messageBar().pushMessage("Success", f"Excel file created: {output_file}", level=Qgis.Success)
