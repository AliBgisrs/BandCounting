from PyQt5 import QtWidgets, uic
import os

class BandCounterDialog(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        ui_path = os.path.join(os.path.dirname(__file__), 'BandCounterDialog.ui')
        uic.loadUi(ui_path, self)

        self.pushButtonBrowseInput.clicked.connect(self.browse_input_folder)
        self.pushButtonBrowseOutput.clicked.connect(self.browse_output_folder)

    def browse_input_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Select Input Folder")
        if folder:
            self.lineEditInputFolderPath.setText(folder)

    def browse_output_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if folder:
            self.lineEditOutputFolderPath.setText(folder)
