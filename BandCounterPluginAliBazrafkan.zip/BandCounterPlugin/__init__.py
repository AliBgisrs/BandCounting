def classFactory(iface):
    from .BandCounterPlugin import BandCounterPlugin
    return BandCounterPlugin(iface)
